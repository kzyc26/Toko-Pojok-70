<?php
// $base_url = "http://localhost/webdev/project-kelompok/project-kelompok/ajax_coba/"
    // $base_url = "http://jmswijaya.com/phpmyadmin/"; //database
    $base_url = "localhost/webdev/project-kelompok/project-kelompok/";
    $servername = 'jmswijaya.com';
    $username 	= 'isb18';
    $password 	= 'Isb_2018';
    $dbname 	= 'store18_2';
?>